(() => {
const ID="clicksimple-host", old=document.getElementById(ID);
if(old){old.shadowRoot.querySelector(".cs-panel").classList.toggle("cs-hidden");return;}
const host=document.createElement("div");host.id=ID;host.style.cssText="all:initial;position:fixed;z-index:2147483647;top:18px;right:18px";
document.documentElement.appendChild(host);const sh=host.attachShadow({mode:"open"});
const KEYS=["tag", "question", "intro", "form", "formDesc", "find", "findDesc", "nav", "navDesc", "custom", "customDesc", "placeholder", "findBtn", "back", "next", "finish", "step", "why", "reason", "note", "noMatch", "noFields", "noNav", "searchTitle", "goalTitle", "empty"], DATA={"en": ["LANGUAGE", "What would you like to do?", "Choose a task. ClickSimple will guide you through this page one step at a time.", "Fill out a form", "Find fields and understand what to enter.", "Find something", "Search this page and jump to matching places.", "Navigate this website", "Explore useful links, buttons and sections.", "Describe my task", "Tell us what you're trying to accomplish.", "What are you looking for?", "Find it", "Back to tasks", "Next result →", "Finish", "RESULT", "Why am I seeing this?", "This part of the page contains text that matches your search.", "Review the highlighted item. You stay in control of every click and submission.", "I couldn't find a clear match. Try a shorter or different search term.", "I couldn't find visible form fields on this page.", "I couldn't find visible links or buttons on this page.", "Search this page", "What are you trying to do?", "Please enter something to search for."], "hi": ["भाषा", "आप क्या करना चाहते हैं?", "एक काम चुनें। ClickSimple आपको इस पेज पर चरण-दर-चरण मार्गदर्शन करेगा।", "फ़ॉर्म भरें", "फ़ॉर्म के फ़ील्ड खोजें और समझें कि क्या भरना है।", "कुछ खोजें", "पेज पर खोजें और मिलते-जुलते स्थान पर जाएँ।", "इस वेबसाइट पर जाएँ", "उपयोगी लिंक, बटन और सेक्शन देखें।", "अपना काम बताएँ", "बताएँ कि आप क्या करना चाहते हैं।", "आप क्या खोज रहे हैं?", "खोजें", "सभी काम", "अगला परिणाम →", "समाप्त", "परिणाम", "यह परिणाम क्यों दिख रहा है?", "इस हिस्से में आपके खोज शब्दों से मिलता-जुलता टेक्स्ट है।", "हाइलाइट किए गए विकल्प को देखें। क्लिक और सबमिट करने का नियंत्रण आपके पास है।", "स्पष्ट परिणाम नहीं मिला। छोटा या दूसरा शब्द आज़माएँ।", "इस पेज पर फ़ॉर्म फ़ील्ड नहीं मिले।", "इस पेज पर लिंक या बटन नहीं मिले।", "इस पेज पर खोजें", "आप क्या करना चाहते हैं?", "कृपया खोजने के लिए कुछ लिखें।"], "zh": ["语言", "你想做什么？", "选择一项任务。ClickSimple 会一步一步引导你浏览此页面。", "填写表单", "查找表单字段并了解需要填写什么。", "查找内容", "搜索此页面并跳转到匹配的位置。", "浏览此网站", "探索有用的链接、按钮和页面区域。", "描述我的任务", "告诉我们你想完成什么。", "你要查找什么？", "查找", "返回任务", "下一个结果 →", "完成", "结果", "为什么显示这个结果？", "页面的这一部分包含与你的搜索相匹配的文字。", "请检查高亮内容。是否点击或提交由你决定。", "没有找到明确匹配项。请尝试更短或不同的关键词。", "此页面上没有找到可见的表单字段。", "此页面上没有找到可见链接或按钮。", "搜索此页面", "你想完成什么？", "请输入搜索内容。"], "es": ["IDIOMA", "¿Qué te gustaría hacer?", "Elige una tarea. ClickSimple te guiará paso a paso por esta página.", "Rellenar un formulario", "Encuentra campos y entiende qué debes introducir.", "Buscar algo", "Busca en esta página y salta a los lugares coincidentes.", "Navegar por este sitio", "Explora enlaces, botones y secciones útiles.", "Describe mi tarea", "Cuéntanos qué quieres conseguir.", "¿Qué estás buscando?", "Buscar", "Volver a las tareas", "Siguiente resultado →", "Terminar", "RESULTADO", "¿Por qué aparece esto?", "Esta parte de la página contiene texto relacionado con tu búsqueda.", "Revisa el elemento resaltado. Tú controlas cada clic y envío.", "No encontré una coincidencia clara. Prueba con un término más corto o diferente.", "No encontré campos de formulario visibles.", "No encontré enlaces ni botones visibles.", "Buscar en esta página", "¿Qué quieres hacer?", "Escribe algo para buscar."], "ar": ["اللغة", "ماذا تريد أن تفعل؟", "اختر مهمة. سيرشدك ClickSimple خلال هذه الصفحة خطوة بخطوة.", "ملء نموذج", "اعثر على الحقول وافهم ما يجب إدخاله.", "ابحث عن شيء", "ابحث في الصفحة وانتقل إلى الأماكن المطابقة.", "تصفح هذا الموقع", "استكشف الروابط والأزرار والأقسام المفيدة.", "صف مهمتي", "أخبرنا بما تريد إنجازه.", "ما الذي تبحث عنه؟", "بحث", "العودة إلى المهام", "النتيجة التالية ←", "إنهاء", "النتيجة", "لماذا تظهر هذه النتيجة؟", "يحتوي هذا الجزء من الصفحة على نص يطابق بحثك.", "راجع العنصر المميز. أنت تتحكم في كل نقرة وإرسال.", "لم أجد تطابقاً واضحاً. جرّب كلمة أقصر أو مختلفة.", "لم يتم العثور على حقول نموذج ظاهرة.", "لم يتم العثور على روابط أو أزرار ظاهرة.", "ابحث في هذه الصفحة", "ماذا تريد أن تفعل؟", "يرجى كتابة ما تريد البحث عنه."], "fr": ["LANGUE", "Que souhaitez-vous faire ?", "Choisissez une tâche. ClickSimple vous guidera étape par étape sur cette page.", "Remplir un formulaire", "Trouvez les champs et comprenez quoi saisir.", "Trouver quelque chose", "Recherchez sur cette page et accédez aux résultats.", "Naviguer sur ce site", "Explorez les liens, boutons et sections utiles.", "Décrire ma tâche", "Dites-nous ce que vous souhaitez accomplir.", "Que recherchez-vous ?", "Rechercher", "Retour aux tâches", "Résultat suivant →", "Terminer", "RÉSULTAT", "Pourquoi ce résultat ?", "Cette partie de la page contient un texte correspondant à votre recherche.", "Vérifiez l'élément surligné. Vous gardez le contrôle des clics et envois.", "Aucune correspondance claire. Essayez un terme plus court ou différent.", "Aucun champ de formulaire visible trouvé.", "Aucun lien ni bouton visible trouvé.", "Rechercher sur cette page", "Que souhaitez-vous faire ?", "Veuillez saisir un terme de recherche."], "bn": ["ভাষা", "আপনি কী করতে চান?", "একটি কাজ বেছে নিন। ClickSimple ধাপে ধাপে সাহায্য করবে।", "ফর্ম পূরণ করুন", "ফর্মের ঘর খুঁজুন এবং কী লিখতে হবে বুঝুন।", "কিছু খুঁজুন", "এই পৃষ্ঠায় খুঁজুন এবং মিল থাকা স্থানে যান।", "এই ওয়েবসাইট ঘুরে দেখুন", "প্রয়োজনীয় লিংক, বোতাম ও বিভাগ খুঁজুন।", "আমার কাজটি বলুন", "আপনি কী করতে চান তা জানান।", "আপনি কী খুঁজছেন?", "খুঁজুন", "কাজে ফিরে যান", "পরের ফলাফল →", "শেষ", "ফলাফল", "এই ফলাফলটি কেন দেখানো হচ্ছে?", "পৃষ্ঠার এই অংশে আপনার অনুসন্ধানের সঙ্গে মেলে এমন লেখা আছে।", "হাইলাইট করা অংশটি দেখুন। নিয়ন্ত্রণ আপনার হাতে।", "স্পষ্ট মিল পাওয়া যায়নি। ছোট বা অন্য শব্দ দিয়ে চেষ্টা করুন।", "দৃশ্যমান ফর্মের ঘর পাওয়া যায়নি।", "দৃশ্যমান লিংক বা বোতাম পাওয়া যায়নি।", "এই পৃষ্ঠায় খুঁজুন", "আপনি কী করতে চান?", "অনুগ্রহ করে অনুসন্ধানের শব্দ লিখুন।"], "pt": ["IDIOMA", "O que você gostaria de fazer?", "Escolha uma tarefa. O ClickSimple vai orientar você passo a passo.", "Preencher um formulário", "Encontre campos e entenda o que preencher.", "Encontrar algo", "Pesquise nesta página e vá até os locais correspondentes.", "Navegar neste site", "Explore links, botões e seções úteis.", "Descrever minha tarefa", "Conte o que você está tentando fazer.", "O que você está procurando?", "Pesquisar", "Voltar às tarefas", "Próximo resultado →", "Concluir", "RESULTADO", "Por que estou vendo isso?", "Esta parte da página contém texto relacionado à sua pesquisa.", "Confira o item destacado. Você controla cada clique e envio.", "Não encontrei uma correspondência clara. Tente outro termo.", "Não encontrei campos de formulário visíveis.", "Não encontrei links ou botões visíveis.", "Pesquisar nesta página", "O que você quer fazer?", "Digite algo para pesquisar."], "ru": ["ЯЗЫК", "Что вы хотите сделать?", "Выберите задачу. ClickSimple будет пошагово помогать вам на этой странице.", "Заполнить форму", "Найдите поля формы и узнайте, что вводить.", "Найти что-нибудь", "Найдите информацию на странице и перейдите к совпадениям.", "Навигация по сайту", "Изучите полезные ссылки, кнопки и разделы.", "Описать мою задачу", "Расскажите, что вы хотите сделать.", "Что вы ищете?", "Найти", "Назад к задачам", "Следующий результат →", "Готово", "РЕЗУЛЬТАТ", "Почему показан этот результат?", "Эта часть страницы содержит текст, соответствующий вашему запросу.", "Проверьте выделенный элемент. Вы сами решаете, нажимать ли на него.", "Точное совпадение не найдено. Попробуйте другой запрос.", "Видимые поля формы не найдены.", "Видимые ссылки или кнопки не найдены.", "Поиск на странице", "Что вы хотите сделать?", "Введите запрос для поиска."], "ur": ["زبان", "آپ کیا کرنا چاہتے ہیں؟", "ایک کام منتخب کریں۔ ClickSimple قدم بہ قدم رہنمائی کرے گا۔", "فارم پُر کریں", "فارم کے خانے تلاش کریں اور سمجھیں کہ کیا درج کرنا ہے۔", "کچھ تلاش کریں", "صفحے پر تلاش کریں اور متعلقہ جگہ پر جائیں۔", "اس ویب سائٹ پر جائیں", "مفید لنکس، بٹن اور حصے دیکھیں۔", "اپنا کام بیان کریں", "بتائیں کہ آپ کیا کرنا چاہتے ہیں۔", "آپ کیا تلاش کر رہے ہیں؟", "تلاش کریں", "کاموں پر واپس جائیں", "اگلا نتیجہ ←", "مکمل", "نتیجہ", "یہ نتیجہ کیوں دکھایا گیا؟", "صفحے کے اس حصے میں آپ کی تلاش سے ملتا جلتا متن موجود ہے۔", "نمایاں حصے کو دیکھیں۔ اختیار آپ کے پاس ہے۔", "واضح نتیجہ نہیں ملا۔ کوئی مختصر یا مختلف لفظ آزمائیں۔", "فارم کے نمایاں خانے نہیں ملے۔", "نمایاں لنکس یا بٹن نہیں ملے۔", "اس صفحے پر تلاش کریں", "آپ کیا کرنا چاہتے ہیں؟", "براہ کرم تلاش کے لیے کچھ لکھیں۔"]};
const LANGS=[["en","English"],["hi","हिन्दी · Hindi"],["zh","中文 · Chinese"],["es","Español · Spanish"],["ar","العربية · Arabic"],["fr","Français · French"],["bn","বাংলা · Bengali"],["pt","Português · Portuguese"],["ru","Русский · Russian"],["ur","اردو · Urdu"]];
let lang="en",steps=[],idx=0,marked=null;
const t=k=>DATA[lang][KEYS.indexOf(k)]||DATA.en[KEYS.indexOf(k)]||k;
sh.innerHTML=`<style>
*{box-sizing:border-box}.cs-panel{font:14px Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;width:360px;max-height:calc(100vh - 36px);overflow:auto;background:#17171b;color:#f4f2ed;border:1px solid #38383f;border-radius:20px;box-shadow:0 18px 60px #0008;padding:16px}.cs-hidden{display:none!important}.head{display:flex;align-items:center;gap:10px;padding-bottom:12px;border-bottom:1px solid #34343a}.logo{width:38px;height:38px;border-radius:12px;background:#b9f36b;color:#17171b;display:grid;place-items:center;font-size:23px;flex:none}.brand{font-size:16px;font-weight:850;letter-spacing:-.5px;flex:1}.brand span{color:#b9f36b}.tagline{display:block;color:#85858e;font-size:8px;letter-spacing:1px;margin-top:2px;font-weight:750}.close{border:1px solid #414149;background:#25252b;color:#e8e6e1;border-radius:9px;padding:7px 10px;cursor:pointer}.sub{font-size:11px;color:#a3a2aa;margin:12px 0 14px;line-height:1.5}.label{font-size:9px;color:#b9f36b;font-weight:850;letter-spacing:1.3px}.select,.input{width:100%;padding:11px 12px;border:1px solid #414149;border-radius:10px;font-size:13px;background:#232329;color:#f4f2ed;margin:7px 0 14px;outline:none}.select:focus,.input:focus{border-color:#b9f36b;box-shadow:0 0 0 3px #b9f36b20}.question{font-size:19px;font-weight:850;letter-spacing:-.6px;margin:10px 0 6px}.copy{font-size:12px;line-height:1.55;color:#aaa9b0;margin:0 0 13px}.option{width:100%;display:block;text-align:left;padding:12px 13px;margin:8px 0;border:1px solid #38383f;border-radius:12px;background:#222227;color:#f4f2ed;cursor:pointer;transition:.15s}.option:hover{border-color:#b9f36b;background:#292d23;transform:translateY(-1px)}.option b{display:block;font-size:13px}.option small{display:block;color:#96959e;font-size:11px;margin-top:4px;line-height:1.4}.primary{background:#b9f36b;color:#17171b;border:0;border-radius:10px;padding:11px 14px;font-weight:850;cursor:pointer}.secondary{background:#29292f;color:#e9e7e2;border:1px solid #414149;border-radius:10px;padding:11px 14px;cursor:pointer}.row{display:flex;gap:8px;margin-top:13px}.row button{flex:1}.step{font-size:10px;color:#b9f36b;font-weight:850;letter-spacing:1px;margin:16px 0 8px}.instruction{font-size:14px;line-height:1.6;margin:0 0 10px;color:#f1efe9}.reason{font-size:11px;color:#c0bfc5;background:#24242a;border:1px solid #38383f;padding:11px;border-radius:10px;line-height:1.5;margin:12px 0}.reason b{color:#b9f36b}.progress{height:6px;background:#36363d;border-radius:9px;overflow:hidden;margin-top:14px}.progress span{display:block;height:100%;background:#b9f36b;border-radius:9px}.note{font-size:10px;color:#85858e;line-height:1.5;margin-top:13px}.cs-target{outline:3px solid #b9f36b!important;outline-offset:4px!important;scroll-margin:110px!important;box-shadow:0 0 0 7px #b9f36b25!important}.cs-panel[dir=rtl]{direction:rtl;text-align:right}
@media(max-width:420px){.cs-panel{width:min(360px,calc(100vw - 24px));max-height:calc(100vh - 24px)}}
</style><section class="cs-panel" role="dialog" aria-label="ClickSimple assistant"><div class="head"><div class="logo" aria-hidden="true">🐈‍⬛</div><div class="brand">Click<span>Simple</span><small class="tagline">LET EVIL LARRY HELP YOU</small></div><button class="close" aria-label="Close">✕</button></div><p class="sub">Ugh. This page looks complicated. Pick a task and I'll point you in the right direction.</p><div class="body"></div></section>`;
const panel=sh.querySelector(".cs-panel"),body=sh.querySelector(".body");
sh.querySelector(".close").onclick=()=>{clear();panel.classList.add("cs-hidden")};
const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const norm=s=>(s||"").toLocaleLowerCase().normalize("NFKC").replace(/[’‘]/g,"'").replace(/[^\p{L}\p{N}]+/gu," ").replace(/\s+/g," ").trim();
function visible(e){if(!e||!e.isConnected)return false;const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden"&&Number(s.opacity)!==0}
function label(e){const labs=e.labels&&e.labels.length?[...e.labels].map(x=>x.innerText).join(" "):"";return [e.getAttribute("aria-label"),e.getAttribute("placeholder"),e.getAttribute("alt"),e.title,labs,e.innerText,e.textContent,e.value,e.placeholder,e.name,e.id].filter(Boolean).join(" ").replace(/\s+/g," ").trim()}
function collect(sel){return [...document.querySelectorAll(sel)].filter(e=>!host.contains(e)&&visible(e))}
function clear(){if(marked&&document.contains(marked))marked.classList.remove("cs-target");marked=null}
function jump(e){
  clear();
  if(!e || !e.isConnected) return;
  marked=e;
  e.classList.add("cs-target");

  // Let the browser finish laying out the page before calculating positions.
  requestAnimationFrame(()=>{
    if(!e.isConnected) return;
    const rect=e.getBoundingClientRect();
    const targetTop=window.scrollY+rect.top-(window.innerHeight/2)+(rect.height/2);

    // Move the main page as well as any nested scrollable panel containing the match.
    window.scrollTo({top:Math.max(0,targetTop),behavior:"smooth"});

    let parent=e.parentElement;
    while(parent && parent!==document.body && parent!==document.documentElement){
      const style=getComputedStyle(parent);
      const canScroll=/(auto|scroll|overlay)/.test(style.overflowY) && parent.scrollHeight>parent.clientHeight+1;
      if(canScroll){
        const er=e.getBoundingClientRect();
        const pr=parent.getBoundingClientRect();
        const delta=er.top-pr.top-(parent.clientHeight/2)+(er.height/2);
        parent.scrollBy({top:delta,behavior:"smooth"});
        break;
      }
      parent=parent.parentElement;
    }

    // Native fallback handles browser-specific and unusual page layouts.
    try{e.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch(_){
      e.scrollIntoView();
    }
  });
}
function findMatches(q){
  const query=norm(q);if(!query)return[];
  const words=[...new Set(query.split(" ").filter(w=>w.length>0))];
  const selector='a[href],button,input:not([type="hidden"]),textarea,select,[role="button"],[role="link"],h1,h2,h3,h4,h5,h6,p,li,label,summary,td,th,section,article,div,span';
  const candidates=collect(selector),found=[],seen=new Set();
  const add=(e,raw)=>{
    if(!e||!visible(e)||host.contains(e))return;
    const txt=norm(raw||label(e));if(!txt)return;
    const hits=words.filter(w=>txt.includes(w)).length;
    if(hits!==words.length)return;
    const key=e.tagName+":"+txt.slice(0,260);if(seen.has(key))return;seen.add(key);
    const tag=e.tagName.toLowerCase();let score=hits*12;
    if(txt.includes(query))score+=24;
    if(["a","button","h1","h2","h3","h4","h5","h6","label","input","textarea","select"].includes(tag))score+=12;
    if(["section","article","div","span"].includes(tag))score-=5;
    if(txt.length<220)score+=Math.max(0,12-Math.floor(txt.length/25));
    if(txt.length>700)score-=15;
    found.push({e,txt,score});
  };
  // Search semantic page elements, including text that was split across child elements.
  for(const e of candidates){
    const raw=label(e);if(raw.length>12000)continue;
    add(e,raw);
  }
  // Also walk visible text nodes so plain text outside common page elements is searchable.
  try{
    const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{acceptNode(node){
      const value=node.nodeValue||"";if(!value.trim())return NodeFilter.FILTER_REJECT;
      const parent=node.parentElement;if(!parent||host.contains(parent)||/^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE)$/i.test(parent.tagName))return NodeFilter.FILTER_REJECT;
      return visible(parent)?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT;
    }});
    let node;while((node=walker.nextNode())){
      const txt=node.nodeValue||"",normalized=norm(txt);if(!words.every(w=>normalized.includes(w)))continue;
      let e=node.parentElement,stepsUp=0;
      while(e&&e!==document.body&&stepsUp<5&&!/^(A|BUTTON|P|LI|LABEL|SUMMARY|TD|TH|H[1-6]|SECTION|ARTICLE|DIV)$/i.test(e.tagName)){e=e.parentElement;stepsUp++}
      add(e||node.parentElement,txt);
    }
  }catch(_){/* Some unusual documents may restrict text traversal. */}
  // Keep the most useful target first and avoid returning a parent and its nearly identical child.
  found.sort((a,b)=>b.score-a.score||a.txt.length-b.txt.length);
  const selected=[];
  for(const item of found){
    if(selected.some(x=>x.e===item.e))continue;
    selected.push(item);
    if(selected.length>=40)break;
  }
  return selected.map(m=>({el:m.e,title:m.txt.slice(0,100),detail:m.txt.slice(0,240),reason:t("reason")}));
}
function formSteps(){return collect('input:not([type="hidden"]):not([type="submit"]):not([type="button"]),textarea,select').filter(e=>!e.disabled).map((e,i,a)=>({el:e,title:t("form")+" "+(i+1)+"/"+a.length,detail:label(e)||"Form field",reason:t("reason")}))}
function navSteps(){return collect('a[href],button,[role="button"],[role="link"],summary').filter(e=>label(e).length>1).map(e=>({el:e,title:label(e).slice(0,85),detail:label(e),reason:t("reason")}))}
function home(){clear();panel.dir=["ar","ur"].includes(lang)?"rtl":"ltr";body.innerHTML=`<label class="label">${t("tag")}</label><select class="select" id="language">${LANGS.map(([v,n])=>`<option value="${v}" ${v===lang?"selected":""}>${n}</option>`).join("")}</select><div class="question">${t("question")}</div><p class="copy">${t("intro")}</p><button class="option" data-task="form"><b>📝 ${t("form")}</b><small>${t("formDesc")}</small></button><button class="option" data-task="find"><b>🔎 ${t("find")}</b><small>${t("findDesc")}</small></button><button class="option" data-task="nav"><b>🧭 ${t("nav")}</b><small>${t("navDesc")}</small></button><button class="option" data-task="custom"><b>🐾 ${t("custom")}</b><small>${t("customDesc")}</small></button><p class="note">🐈‍⬛ Larry says: no panic. You stay in control of every click.</p>`;
body.querySelector("#language").onchange=e=>{lang=e.target.value;home()};body.querySelectorAll("[data-task]").forEach(b=>b.onclick=()=>begin(b.dataset.task))}
function begin(task){if(task==="form"){let a=formSteps();start(a.length?a:[{el:null,title:t("noFields"),detail:t("noFields"),reason:t("reason")}]);return}if(task==="nav"){let a=navSteps();start(a.length?a:[{el:null,title:t("noNav"),detail:t("noNav"),reason:t("reason")}]);return}
body.innerHTML=`<div class="question">${task==="find"?t("searchTitle"):t("goalTitle")}</div><p class="copy">${t("intro")}</p><input class="input" id="query" placeholder="${esc(task==="find"?t("placeholder"):t("goalPlaceholder"))}"><div class="row"><button class="secondary" id="back">${t("back")}</button><button class="primary" id="go">${t("findBtn")}</button></div>`;
body.querySelector("#back").onclick=home;const run=()=>{let q=body.querySelector("#query").value.trim();if(!q){body.querySelector("#query").placeholder=t("empty");return}start(findMatches(q))};body.querySelector("#go").onclick=run;body.querySelector("#query").onkeydown=e=>{if(e.key==="Enter")run()};body.querySelector("#query").focus()}
function start(a){steps=a.length?a:[{el:null,title:t("noMatch"),detail:t("noMatch"),reason:t("reason")}];idx=0;render()}
function render(){const s=steps[idx];if(s.el)jump(s.el);else clear();let pct=Math.round((idx+1)/steps.length*100);body.innerHTML=`<div class="step">${t("step")} ${idx+1} / ${steps.length}</div><div class="question">${esc(s.title)}</div><p class="instruction">${esc(s.detail)}</p><div class="reason"><b>${t("why")}</b><br>${esc(s.reason)}</div><div class="progress"><span style="width:${pct}%"></span></div><div class="row"><button class="secondary" id="back">${t("back")}</button><button class="primary" id="next">${idx===steps.length-1?t("finish"):t("next")}</button></div><p class="note">🐈‍⬛ Larry says: no panic. You stay in control of every click.</p>`;body.querySelector("#back").onclick=home;body.querySelector("#next").onclick=()=>{if(idx<steps.length-1){idx++;render()}else home()}}
home();
})();