# ClickSimple

A Chrome extension that helps people use complicated websites through four guided tasks: Fill out a form, Find something, Navigate this website, and Describe my task.

## Features
- Preserves the original four-task experience.
- Find something searches visible page text and controls, then smoothly scrolls to and highlights matching places.
- Multiple matches can be reviewed one by one.
- Assistant interface in English, Hindi, Mandarin Chinese, Spanish, Arabic, French, Bengali, Portuguese, Russian and Urdu.
- Form-field and navigation discovery.
- No external AI API or account required.

## Install
1. Extract this folder.
2. Open `chrome://extensions`.
3. Enable Developer mode.
4. Click Load unpacked and choose this folder (the one containing `manifest.json`).
5. Open a normal website, click the extension icon, then Open assistant.

For a predictable demo, open `demo/test-page.html`. If Chrome blocks extension access to local files, open the extension Details page and enable Allow access to file URLs.

## GitHub Pages
Upload the project files to a GitHub repository. Under Settings → Pages, choose Deploy from a branch, select `main` and `/docs`, then save. Pages hosts the project website, not the extension itself.

## Permissions and limitations
The extension uses `activeTab` and `scripting`, so it runs on ordinary websites after the user activates it. Chrome blocks extensions from injecting scripts into protected pages such as `chrome://` pages and the Chrome Web Store. Some embedded frames, canvas interfaces and custom components may not expose readable text.

## Privacy
Page text is inspected locally in the active tab to find matches. No page content is sent to a server. Users remain in control of clicks and form submissions.
