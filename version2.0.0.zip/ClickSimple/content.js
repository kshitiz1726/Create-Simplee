(() => {
  const HOST_ID = "clicksimple-host";
  const oldHost = document.getElementById(HOST_ID);
  if (oldHost) {
    oldHost.shadowRoot.querySelector(".cs-panel").classList.toggle("cs-hidden");
    return;
  }

  const host = document.createElement("div");
  host.id = HOST_ID;
  host.style.cssText = "all:initial;position:fixed;z-index:2147483647;top:18px;right:18px;";
  document.documentElement.appendChild(host);
  const shadow = host.attachShadow({mode:"open"});

  shadow.innerHTML = `
  <style>
    *{box-sizing:border-box}
    .cs-panel{font-family:Arial,sans-serif;width:350px;max-height:calc(100vh - 36px);overflow:auto;background:#fff;color:#17231d;border:1px solid #dce7df;border-radius:16px;box-shadow:0 12px 45px #102b1d35;padding:17px}
    .cs-hidden{display:none!important}.cs-head{display:flex;align-items:center;gap:9px}.cs-logo{width:32px;height:32px;border-radius:10px;background:#e5f5eb;color:#16834a;display:grid;place-items:center;font-weight:800}.cs-title{font-size:16px;font-weight:800;flex:1}.cs-close{border:0;background:#f1f4f1;border-radius:8px;padding:7px 10px;cursor:pointer}
    .cs-sub{font-size:12px;color:#68756d;margin:4px 0 15px}.cs-question{font-size:17px;font-weight:700;margin:12px 0 8px}.cs-copy{font-size:12px;line-height:1.5;color:#65736a;margin:0 0 12px}
    .cs-option{width:100%;display:block;text-align:left;padding:11px;margin:7px 0;border:1px solid #e0e8e2;border-radius:10px;background:#fff;color:#1c2b22;cursor:pointer}.cs-option:hover,.cs-option:focus{border-color:#16834a;background:#f5fbf7;outline:2px solid #bce4c9}.cs-option b{display:block;font-size:13px}.cs-option small{display:block;color:#728077;font-size:11px;margin-top:4px}
    .cs-input{width:100%;;padding:11px;border:1px solid #ccd8cf;border-radius:9px;font-size:13px;margin:8px 0}.cs-primary{background:#16834a;color:#fff;border:0;border-radius:9px;padding:11px 14px;font-weight:700;cursor:pointer}.cs-secondary{background:#f0f4f1;color:#24402e;border:0;border-radius:9px;padding:11px 14px;cursor:pointer}.cs-row{display:flex;gap:8px;margin-top:13px}.cs-row button{flex:1}
    .cs-step{font-size:11px;color:#16834a;font-weight:700;margin:15px 0 7px}.cs-instruction{font-size:14px;line-height:1.55;margin:0 0 10px}.cs-reason{font-size:11px;color:#65736a;background:#f5f8f5;padding:9px;border-radius:8px;line-height:1.45;margin:10px 0}.cs-progress{height:6px;background:#e9eee9;border-radius:9px;overflow:hidden}.cs-progress span{display:block;height:100%;background:#16834a;transition:width .2s}.cs-note{font-size:11px;color:#78847c;line-height:1.45;margin-top:12px}
    .cs-target{outline:3px solid #18a45a!important;outline-offset:4px!important;scroll-margin:110px!important;position:relative!important}.cs-pill{display:inline-block;background:#e6f5eb;color:#167843;padding:4px 7px;border-radius:20px;font-size:10px;font-weight:700;margin-bottom:6px}
    @media(max-width:420px){.cs-panel{width:min(350px,calc(100vw - 24px));max-height:calc(100vh - 24px)}}
  </style>
  <section class="cs-panel" role="dialog" aria-label="ClickSimple assistant">
    <div class="cs-head"><div class="cs-logo">C</div><div class="cs-title">ClickSimple</div><button class="cs-close" aria-label="Close assistant">✕</button></div>
    <p class="cs-sub">Complex interfaces. Simple instructions.</p><div class="cs-content"></div>
  </section>`;

  const panel = shadow.querySelector(".cs-panel");
  const content = shadow.querySelector(".cs-content");
  let steps = [], current = 0, highlighted = null, lastGoal = "";

  shadow.querySelector(".cs-close").addEventListener("click", () => {
    clearHighlight(); panel.classList.add("cs-hidden");
  });

  const escapeHTML = value => String(value).replace(/[&<>"']/g, ch => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  }[ch]));

  function visible(el) {
    const rect = el.getBoundingClientRect(), style = getComputedStyle(el);
    return rect.width > 0 && rect.height > 0 &&
      style.visibility !== "hidden" && style.display !== "none" &&
      Number(style.opacity) !== 0;
  }

  function labelOf(el) {
    const label = el.labels && el.labels.length ? [...el.labels].map(x => x.innerText).join(" ") : "";
    const bits = [
      el.getAttribute("aria-label"), el.getAttribute("title"),
      el.innerText, el.value, el.placeholder, el.name, el.id, label,
      el.getAttribute("alt")
    ].filter(Boolean);
    return bits.join(" ").replace(/\s+/g," ").trim().slice(0,180);
  }

  function candidates() {
    const selector = 'a[href],button,input:not([type="hidden"]),textarea,select,[role="button"],[role="link"],h1,h2,h3,[tabindex]:not([tabindex="-1"])';
    return [...document.querySelectorAll(selector)]
      .filter(el => !host.contains(el) && visible(el))
      .filter(el => !el.disabled && el.getAttribute("aria-hidden") !== "true")
      .slice(0,500);
  }

  function clearHighlight() {
    if (highlighted) highlighted.classList.remove("cs-target");
    highlighted = null;
  }

  const dictionaries = {
    scholarship: ["scholarship","financial aid","fee assistance","grant","funding","apply now","application"],
    marksheet: ["marksheet","mark sheet","results","result","grade card","transcript","download","academic record"],
    contact: ["contact","contact us","reach us","email","phone","support","help","enquiry","inquiry"],
    login: ["login","log in","sign in","student portal","account","username","password"],
    register: ["register","registration","sign up","create account","enrol","enroll"],
    upload: ["upload","attach file","choose file","browse files","submit document"],
    download: ["download","pdf","export","save file","get document"],
    fees: ["fee payment","pay fees","payment","fees","billing","receipt"],
    admission: ["admission","apply","application form","enrolment","enrollment","eligibility"],
    search: ["search","find","look up","query"]
  };

  const stopWords = new Set(["i","want","to","the","a","an","for","my","me","please","help","with","on","in","how","can","do","get","find","this","that","page","website"]);

  function inferTerms(goal) {
    const lower = goal.toLowerCase();
    const terms = new Set();
    Object.entries(dictionaries).forEach(([key, words]) => {
      if (lower.includes(key) || words.some(word => lower.includes(word))) words.forEach(w => terms.add(w));
    });
    lower.split(/[^a-z0-9]+/).filter(w => w.length > 2 && !stopWords.has(w)).forEach(w => terms.add(w));
    return [...terms];
  }

  function scoreElement(el, terms, goal) {
    const label = labelOf(el).toLowerCase();
    if (!label) return 0;
    let score = 0;
    const tag = el.tagName.toLowerCase();
    const type = (el.getAttribute("type") || "").toLowerCase();

    for (const term of terms) {
      if (label.includes(term)) score += term.includes(" ") ? 7 : 3;
    }
    if (goal.toLowerCase().includes("scholarship") && /scholarship|financial aid|grant/.test(label)) score += 14;
    if (/apply|application/.test(goal.toLowerCase()) && /apply|application|admission/.test(label)) score += 9;
    if (/mark.?sheet|result|transcript/.test(goal.toLowerCase()) && /mark.?sheet|result|transcript|grade card/.test(label)) score += 14;
    if (/contact|email|phone|support/.test(goal.toLowerCase()) && /contact|email|phone|support|help/.test(label)) score += 12;
    if (/download/.test(goal.toLowerCase()) && (/download/.test(label) || type === "file")) score += 10;
    if (/upload|attach/.test(goal.toLowerCase()) && (type === "file" || /upload|attach|choose file/.test(label))) score += 12;

    if (tag === "a" || tag === "button" || el.getAttribute("role") === "button") score += 2;
    if (tag === "input" || tag === "textarea" || tag === "select") score += 1;
    if (tag.match(/^h[1-3]$/)) score -= 1;
    if (type === "submit") score += 2;
    if (el.getAttribute("aria-disabled") === "true") score -= 5;
    return score;
  }

  function makeGoalSteps(goal) {
    const terms = inferTerms(goal);
    const ranked = candidates().map(el => ({el, score:scoreElement(el,terms,goal), label:labelOf(el)}))
      .filter(item => item.score >= 3)
      .sort((a,b) => b.score-a.score);
    const unique = [];
    const seen = new Set();
    for (const item of ranked) {
      const key = item.label.toLowerCase();
      if (!seen.has(key)) { seen.add(key); unique.push(item); }
      if (unique.length >= 5) break;
    }
    if (!unique.length) {
      return [{
        el:null,title:"I couldn't find a confident match yet",
        detail:`I couldn't identify a clearly matching control for “${goal}”. Try a shorter phrase, or look for a menu or search option.`,
        reason:"ClickSimple only suggests elements when the visible page gives it enough clues. It won't guess or click for you."
      }];
    }
    return unique.map((item,index) => ({
      el:item.el,
      title:index===0 ? "Best place to start" : `Another relevant option`,
      detail:`Look for “${item.label || item.el.tagName}”. This appears related to your goal: “${goal}”.`,
      reason:`Matched words and labels on the page against your request. Relevance score: ${item.score}.`
    }));
  }

  function taskSteps(task) {
    if (task === "form") {
      const fields = candidates().filter(el => /^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName) && el.type !== "hidden");
      return fields.slice(0,8).map((el,i)=>({
        el,title:`Form field ${i+1} of ${Math.min(fields.length,8)}`,
        detail:`Find “${labelOf(el) || el.getAttribute("type") || "form field"}”. Read its label and complete it if appropriate.`,
        reason:"Detected a visible form control on this page."
      }));
    }
    if (task === "navigate") return makeGoalSteps("navigate to the main sections and useful links");
    if (task === "search") {
      const fields = candidates().filter(el => el.tagName === "INPUT" && /search|query|find/i.test(labelOf(el)+" "+el.type));
      if (fields.length) return fields.slice(0,3).map(el=>({el,title:"Possible search field",detail:`This field may help you search: “${labelOf(el)}”.`,reason:"Matched search-related labels and input attributes."}));
      return makeGoalSteps("search this website");
    }
    return [];
  }

  function showHome() {
    clearHighlight();
    content.innerHTML = `
      <div class="cs-question">What would you like to do?</div>
      <p class="cs-copy">Tell ClickSimple your goal. It will look for relevant options on this page and guide you towards them.</p>
      <button class="cs-option" data-task="form"><b>📝 Fill out a form</b><small>Find fields and move through them one at a time.</small></button>
      <button class="cs-option" data-task="search"><b>🔎 Find something</b><small>Locate a search field or matching content.</small></button>
      <button class="cs-option" data-task="navigate"><b>🧭 Navigate this website</b><small>Find useful links and page sections.</small></button>
      <button class="cs-option" data-task="custom"><b>💬 Describe my goal</b><small>Example: I want to apply for a scholarship.</small></button>
      <p class="cs-note">You stay in control. ClickSimple highlights suggestions but never submits forms or makes purchases.</p>`;
    content.querySelectorAll("[data-task]").forEach(btn=>btn.addEventListener("click",()=>begin(btn.dataset.task)));
  }

  function begin(task) {
    if (task === "custom") {
      content.innerHTML = `<div class="cs-question">What are you trying to do?</div><p class="cs-copy">Describe it in your own words. For example, “I want to download my marksheet”.</p><input class="cs-input" id="cs-goal" aria-label="Describe your goal" placeholder="I want to..."><div class="cs-row"><button class="cs-secondary" id="cs-back">Back</button><button class="cs-primary" id="cs-go">Find my next step</button></div>`;
      content.querySelector("#cs-back").addEventListener("click",showHome);
      const run=()=>{const goal=content.querySelector("#cs-goal").value.trim();if(goal.length<3)return;lastGoal=goal;startSteps(makeGoalSteps(goal));};
      content.querySelector("#cs-go").addEventListener("click",run);
      content.querySelector("#cs-goal").addEventListener("keydown",e=>{if(e.key==="Enter")run();});
      content.querySelector("#cs-goal").focus();
      return;
    }
    if (task === "form" || task === "search" || task === "navigate") {
      lastGoal = task;
      startSteps(taskSteps(task));
    }
  }

  function startSteps(nextSteps) {
    steps=nextSteps;
    current=0;
    if (!steps.length) steps=[{el:null,title:"No matching elements found",detail:"This page may not contain the type of control you're looking for. Try describing your goal instead.",reason:"No suitable visible controls were detected."}];
    renderStep();
  }

  function renderStep() {
    clearHighlight();
    const step=steps[current];
    if(step.el && document.contains(step.el)){
      highlighted=step.el;
      highlighted.classList.add("cs-target");
      step.el.scrollIntoView({behavior:"smooth",block:"center"});
    }
    const pct=Math.round(((current+1)/steps.length)*100);
    content.innerHTML=`
      <div class="cs-step">SUGGESTION ${current+1} OF ${steps.length}</div>
      <div class="cs-pill">${step.el ? "Relevant page element" : "Try another approach"}</div>
      <div class="cs-question">${escapeHTML(step.title)}</div>
      <p class="cs-instruction">${escapeHTML(step.detail)}</p>
      <div class="cs-reason"><b>Why this suggestion?</b><br>${escapeHTML(step.reason)}</div>
      <div class="cs-progress" role="progressbar" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100"><span style="width:${pct}%"></span></div>
      <div class="cs-row"><button class="cs-secondary" id="cs-home">All tasks</button><button class="cs-primary" id="cs-next">${current===steps.length-1?"Finish":"Next suggestion →"}</button></div>
      <p class="cs-note">Review the highlighted element. Click it yourself only if it matches what you want to do. Suggestions may not be perfect on every website.</p>`;
    content.querySelector("#cs-home").addEventListener("click",showHome);
    content.querySelector("#cs-next").addEventListener("click",()=>{if(current<steps.length-1){current++;renderStep();}else{clearHighlight();showHome();}});
  }

  showHome();
})();