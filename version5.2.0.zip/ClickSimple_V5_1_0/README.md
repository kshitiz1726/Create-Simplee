# ClickSimple V5.1.0 — Guided Browsing Edition

ClickSimple is a local-first Chrome extension that helps people understand and navigate complex websites. It does not call an external AI service, create a cloud account, or send page content to a remote server.

## What's new in V5.1.0

- **Guided cross-page search:** When a search has no result on the current page, users can start a guided journey. ClickSimple keeps the search goal in local extension storage, suggests relevant links or navigation choices, and checks each page the user opens.
- **Journey resumes after navigation:** On pages within the same origin, ClickSimple automatically reopens and checks the saved search. If a journey moves to a different origin or opens in a new tab and Chrome blocks automatic injection, click the ClickSimple toolbar icon on that tab to grant access and resume.
- **Context-aware navigation explanations:** Links are described using their actual destinations. Buttons are explained using available HTML and accessibility metadata, such as form submission, reset behavior, expanded/collapsed state, popup type, and nearby section headings. When the page does not expose a control's exact action, ClickSimple says so rather than inventing an explanation.
- **No generic intent-analysis claims:** Search results now describe the actual element or surrounding section instead of repeating phrases such as “matching key intent”.
- **Local-only journey state:** Search journeys are stored in `chrome.storage.local`, scoped to the tab, and removed when the user finishes the journey or closes the tab.

## How guided search works

1. Open ClickSimple on a website and choose **Find something**.
2. Enter the item or task you are looking for.
3. If it is not present on the current page, choose **Guide me there**.
4. Review the suggested links, use **Highlight this option**, and click the corresponding link on the website yourself.
5. ClickSimple checks the next page and either shows a possible match or suggests the next navigation choices.
6. Choose **Finish search** when done.

ClickSimple does not inspect unopened pages or click links automatically. It guides the user through pages they choose to open. This avoids silently crawling sites or triggering actions on the user's behalf.

## Permissions

- `activeTab`: grants access after the user invokes the extension on a tab.
- `scripting`: injects the local content script into that tab and resumes it after eligible page navigation.
- `storage`: stores the active guided-search goal locally, scoped to a tab.

The extension does **not** request blanket access to all websites. Automatic resumption is available while Chrome's `activeTab` grant remains valid (typically same-origin navigation). On a different origin or a newly opened tab, click the extension icon again on that tab to grant access and continue the saved journey.

## Install in Chrome

1. Extract the ZIP file.
2. Open `chrome://extensions` in Chrome or Edge.
3. Turn on **Developer mode**.
4. Select **Load unpacked** and choose the extracted `ClickSimple_V5_1_0` folder.
5. Pin ClickSimple to the toolbar, open a website, and select **Let Larry help me**.

## Project files

```text
ClickSimple_V5_1_0/
├── manifest.json
├── background.js
├── popup.html
├── popup.css
├── popup.js
├── content.js
├── README.md
└── CHANGELOG.md
```

## Existing V5 behavior retained

- Four modes: Fill out a form, Find something, Navigate this website, and Describe my task.
- Ten language choices and RTL panel direction for Arabic and Urdu.
- Detailed form field guidance and integrated form filtering.
- Visible-element scanning and accessible same-origin iframe traversal.
- Duplicate-word cleanup, highlighted results, and smooth scrolling.
