# Changelog

## V5.1.0 — Guided Browsing Edition
- Added a persistent, tab-scoped guided search journey across pages.
- Added local journey storage and same-origin navigation reinjection through a service worker.
- Added link-route suggestions when the current page has no result.
- Added context-aware descriptions for links, buttons, disclosure controls, forms, and nearby sections.
- Replaced generic “matching key intent” explanations with descriptions grounded in page markup and accessible metadata.
- Kept the extension local-first and avoided blanket all-sites host permissions.

## V5.0.0 — Fully Resolved Edition
- Fixed duplicate word issues across labels.
- Added deep iframe/embedded DOM element collection.
- Added Search Bar inside Fill out a form mode.
- Fixed auto-scrolling across Describe My Task and search modes.
- Restricted results to top 3–5 ranked matches.
