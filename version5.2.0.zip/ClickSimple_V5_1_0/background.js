const journeyKey = tabId => `clicksimple-guided-journey:${tabId}`;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const tabId = sender.tab?.id;
  if (tabId == null || !message?.type?.startsWith("CLICKSIMPLE_")) return false;

  const key = journeyKey(tabId);
  if (message.type === "CLICKSIMPLE_SAVE_JOURNEY") {
    chrome.storage.local.set({ [key]: message.journey })
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
  if (message.type === "CLICKSIMPLE_GET_JOURNEY") {
    chrome.storage.local.get(key)
      .then(result => sendResponse({ journey: result[key] || null }))
      .catch(() => sendResponse({ journey: null }));
    return true;
  }
  if (message.type === "CLICKSIMPLE_CLEAR_JOURNEY") {
    chrome.storage.local.remove(key)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
  return false;
});

// Re-open ClickSimple after a same-origin page navigation when a guided search is active.
// activeTab keeps this scoped to the tab the user explicitly activated; no all-sites
// host permission or remote service is required.
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status !== "complete") return;
  const key = journeyKey(tabId);
  chrome.storage.local.get(key).then(result => {
    if (!result[key]) return;
    chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] }).catch(() => {
      // If the site changed origin, Chrome may require the user to click the extension
      // again to grant activeTab access on that origin. The saved journey remains local.
    });
  }).catch(() => {});
});

chrome.tabs.onRemoved.addListener(tabId => {
  chrome.storage.local.remove(journeyKey(tabId)).catch(() => {});
});

// Carry an active search into tabs opened from the current tab (for example, target="_blank").
// The new tab still needs its own activeTab grant, so users can explicitly relaunch ClickSimple there.
chrome.tabs.onCreated.addListener(tab => {
  const openerId = tab.openerTabId;
  if (openerId == null || tab.id == null) return;
  const sourceKey = journeyKey(openerId);
  chrome.storage.local.get(sourceKey).then(result => {
    const journey = result[sourceKey];
    if (journey) return chrome.storage.local.set({ [journeyKey(tab.id)]: journey });
    return undefined;
  }).catch(() => {});
});
