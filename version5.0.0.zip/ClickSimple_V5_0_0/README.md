# ClickSimple V5.0.0

**Complex interfaces. Simple instructions.**

ClickSimple V5.0.0 is a browser extension that makes websites easy to navigate using smart intent recognition, detailed step-by-step form guidance, multi-language support (10 languages with RTL), and Evil Larry neon branding.

## Installation in Chrome (Windows)
1. Extract `ClickSimple_V5.0.0.zip`.
2. Open Google Chrome and go to `chrome://extensions`.
3. Enable **Developer mode** (top-right).
4. Click **Load unpacked** and select the extracted `ClickSimple` folder containing `manifest.json`.
