# CHANGELOG - ClickSimple V5.0.0

### Added / Upgraded in V5.0.0:
- **Smart Synonym & Intent Matching**: Queries like "reset password", "change pass", or "security credential" match password elements.
- **Detailed Form Field Guidance**: Detailed field-by-field instructions, required statuses, and input types.
- **10-Language Support with RTL**: Full RTL interface support for Arabic and Urdu.
- **Evil Larry Neon Theme**: Retained black cat identity with neon lime accents.
