(() => {
const ID="clicksimple-host", old=document.getElementById(ID);
if(old){old.shadowRoot.querySelector(".cs-panel").classList.toggle("cs-hidden");return;}
const host=document.createElement("div");host.id=ID;host.style.cssText="all:initial;position:fixed;z-index:2147483647;top:18px;right:18px";
document.documentElement.appendChild(host);const sh=host.attachShadow({mode:"open"});

const SYNONYMS = {
  "password": ["pass", "login", "security", "credential", "auth", "reset", "secret"],
  "account": ["profile", "user", "my account", "dashboard", "settings"],
  "billing": ["payment", "card", "invoice", "receipt", "order", "purchase", "subscription", "pay", "checkout"],
  "help": ["support", "faq", "contact", "customer service", "assistance"],
  "email": ["mail", "address", "contact info"],
  "search": ["find", "lookup", "explore", "query"],
  "form": ["input", "submit", "details", "register", "signup", "apply"]
};

const KEYS=["tag", "question", "intro", "form", "formDesc", "find", "findDesc", "nav", "navDesc", "custom", "customDesc", "placeholder", "findBtn", "back", "next", "finish", "step", "why", "reason", "note", "noMatch", "noFields", "noNav", "searchTitle", "goalTitle", "empty"], DATA={"en": ["LANGUAGE", "What would you like to do?", "Choose a task. ClickSimple will guide you through this page one step at a time.", "Fill out a form", "Inspect form fields, understand inputs & required items.", "Find something", "Search this page using smart intent matching.", "Navigate this website", "Explore useful links, buttons and key sections.", "Describe my task", "Tell us what you're trying to accomplish.", "What are you looking for?", "Find it", "Back to tasks", "Next result →", "Finish", "RESULT", "Why am I seeing this?", "This element matches your query or intent.", "Review the highlighted item. You stay in control of every click.", "I couldn't find a clear match. Try a shorter or different search term.", "I couldn't find visible form fields on this page.", "I couldn't find visible links or buttons on this page.", "Search this page", "What are you trying to do?", "Please enter something to search for."], "hi": ["भाषा", "आप क्या करना चाहते हैं?", "एक काम चुनें। ClickSimple आपको इस पेज पर मार्गदर्शन करेगा।", "फ़ॉर्म भरें", "फ़ॉर्म फ़ील्ड देखें और भरें।", "कुछ खोजें", "स्मार्ट तरीके से पेज पर खोजें।", "वेबसाइट देखें", "लिंक और बटन देखें।", "काम बताएँ", "बताएँ कि आप क्या करना चाहते हैं।", "आप क्या खोज रहे हैं?", "खोजें", "पीछे जाएँ", "अगला →", "समाप्त", "परिणाम", "यह क्यों दिख रहा है?", "यह आपके खोज शब्द या उद्देश्य से मेल खाता है।", "हाइलाइट की गई चीज़ देखें। नियंत्रण आपके पास है।", "कोई स्पष्ट परिणाम नहीं मिला।", "फ़ॉर्म नहीं मिला।", "लिंक या बटन नहीं मिले।", "पेज पर खोजें", "आप क्या करना चाहते हैं?", "कृपया कुछ लिखें।"], "zh": ["语言", "你想做什么？", "选择一项任务。ClickSimple 会一步一步引导你。", "填写表单", "查看表单字段及必填项。", "查找内容", "使用智能匹配搜索此页面。", "浏览此网站", "探索有用的链接和按钮。", "描述我的任务", "告诉我们你想完成什么。", "你要查找什么？", "查找", "返回", "下一个 →", "完成", "结果", "为什么显示这个？", "此元素与你的搜索或意图匹配。", "请检查高亮内容。控制权在你手中。", "未找到明确匹配项。", "没有找到表单字段。", "没有找到链接或按钮。", "搜索此页面", "你想做什么？", "请输入搜索内容。"], "es": ["IDIOMA", "¿Qué te gustaría hacer?", "Elige una tarea. ClickSimple te guiará paso a paso.", "Rellenar un formulario", "Inspeccionar campos de formulario y requisitos.", "Buscar algo", "Busca en la página con reconocimiento de intención.", "Navegar por este sitio", "Explora enlaces y botones útiles.", "Describe mi tarea", "Dinos qué quieres lograr.", "¿Qué estás buscando?", "Buscar", "Volver", "Siguiente →", "Terminar", "RESULTADO", "¿Por qué aparece esto?", "Este elemento coincide con tu búsqueda o intención.", "Revisa el elemento resaltado.", "No se encontró coincidencia.", "No hay formularios visibles.", "No hay enlaces o botones visibles.", "Buscar en esta página", "¿Qué quieres hacer?", "Escribe algo para buscar."], "ar": ["اللغة", "ماذا تريد أن تفعل؟", "اختر مهمة. سيرشدك ClickSimple خطوة بخطوة.", "ملء نموذج", "افحص حقول النموذج واعرف البيانات المطلوبة.", "ابحث عن شيء", "ابحث في الصفحة باستخدام التوافق الذكي.", "تصفح هذا الموقع", "استكشف الروابط والأزرار المفيدة.", "صف مهمتي", "أخبرنا بما تريد إنجازه.", "ما الذي تبحث عنه؟", "بحث", "عودة", "النتيجة التالية ←", "إنهاء", "النتيجة", "لماذا تظهر هذه النتيجة؟", "هذا العنصر يطابق بحثك أو قصدك.", "راجع العنصر المميز.", "لم نجد تطابقاً واضحاً.", "لم نجد حقول نموذج ظاهرة.", "لم نجد روابط أو أزرار ظاهرة.", "ابحث في هذه الصفحة", "ماذا تريد أن تفعل؟", "يرجى كتابة كلمة البحث."], "fr": ["LANGUE", "Que souhaitez-vous faire ?", "Choisissez une tâche. ClickSimple vous guidera étape par étape.", "Remplir un formulaire", "Inspecter les champs et champs requis.", "Trouver quelque chose", "Rechercher avec reconnaissance d'intention.", "Naviguer sur ce site", "Explorer les liens et boutons utiles.", "Décrire ma tâche", "Dites-nous votre objectif.", "Que recherchez-vous ?", "Rechercher", "Retour", "Suivant →", "Terminer", "RÉSULTAT", "Pourquoi ce résultat ?", "Cet élément correspond à votre recherche.", "Vérifiez l'élément surligné.", "Aucune correspondance trouvée.", "Aucun champ de formulaire trouvé.", "Aucun lien ou bouton trouvé.", "Rechercher sur cette page", "Que souhaitez-vous faire ?", "Veuillez saisir un terme."], "bn": ["ভাষা", "আপনি কী করতে চান?", "একটি কাজ বেছে নিন। ClickSimple আপনাকে সাহায্য করবে।", "ফর্ম পূরণ করুন", "ফর্মের ঘর ও প্রয়োজনীয় তথ্য বুঝুন।", "কিছু খুঁজুন", "স্মার্ট সার্চ দিয়ে পৃষ্ঠায় খুঁজুন।", "ওয়েবসাইট ঘুরে দেখুন", "প্রয়োজনীয় লিংক ও বোতাম খুঁজুন।", "আমার কাজটি বলুন", "আপনার লক্ষ্য জানান।", "আপনি কী খুঁজছেন?", "খুঁজুন", "পিছনে", "পরের →", "শেষ", "ফলাফল", "কেন দেখানো হচ্ছে?", "এই উপাদানটি আপনার অনুসন্ধানের সঙ্গে মেলে।", "হাইলাইট করা অংশটি দেখুন।", "কোন মিল পাওয়া যায়নি।", "ফর্ম পাওয়া যায়নি।", "লিংক বা বোতাম পাওয়া যায়নি।", "পৃষ্ঠায় খুঁজুন", "আপনি কী করতে চান?", "অনুসন্ধানের শব্দ লিখুন।"], "pt": ["IDIOMA", "O que você gostaria de fazer?", "Escolha uma tarefa. O ClickSimple guiará você.", "Preencher um formulário", "Inspecione os campos e requisitos do formulário.", "Encontrar algo", "Pesquise na página com correspondência inteligente.", "Navegar neste site", "Explore links e botões úteis.", "Descrever minha tarefa", "Conte o que você quer fazer.", "O que você está procurando?", "Pesquisar", "Voltar", "Próximo →", "Concluir", "RESULTADO", "Por que este resultado?", "Este elemento corresponde à sua pesquisa.", "Confira o item destacado.", "Nenhuma correspondência encontrada.", "Nenhum formulário visível.", "Nenhum link ou botão visível.", "Pesquisar na página", "O que você quer fazer?", "Digite algo para pesquisar."], "ru": ["ЯЗЫК", "Что вы хотите сделать?", "Выберите задачу. ClickSimple поможет вам пошагово.", "Заполнить форму", "Проверьте поля формы и узнайте, что вводить.", "Найти что-нибудь", "Умный поиск по странице с учетом синонимов.", "Навигация по сайту", "Изучите полезные ссылки и кнопки.", "Описать мою задачу", "Расскажите о вашей цели.", "Что вы ищете?", "Найти", "Назад", "Далее →", "Готово", "РЕЗУЛЬТАТ", "Почему этот результат?", "Этот элемент соответствует вашему запросу.", "Проверьте выделенный элемент.", "Совпадений не найдено.", "Поля формы не найдены.", "Ссылки или кнопки не найдены.", "Поиск на странице", "Что вы хотите сделать?", "Введите текст для поиска."], "ur": ["زبان", "آپ کیا کرنا چاہتے ہیں؟", "ایک کام منتخب کریں۔ ClickSimple رہنمائی کرے گا۔", "فارم پُر کریں", "فارم کے خانے اور مطلوبہ معلومات دیکھیں۔", "کچھ تلاش کریں", "صفحے پر اسمارٹ سرچ کریں۔", "ویب سائٹ پر جائیں", "مفید لنکس اور بٹن دیکھیں۔", "اپنا کام بیان کریں", "اپنا مقصد بتائیں۔", "آپ کیا تلاش کر رہے ہیں؟", "تلاش کریں", "واپس", "اگلا ←", "مکمل", "نتیجہ", "یہ کیوں دکھایا گیا؟", "یہ عنصر آپ کی تلاش سے مطابقت رکھتا ہے۔", "نمایاں حصہ دیکھیں۔", "کوئی نتیجہ نہیں ملا۔", "فارم کے خانے نہیں ملے۔", "لنکس یا بٹن نہیں ملے۔", "صفحے پر تلاش کریں", "آپ کیا کرنا چاہتے ہیں؟", "تلاش کے لیے کچھ لکھیں۔"]};

const LANGS=[["en","English"],["hi","हिन्दी · Hindi"],["zh","中文 · Chinese"],["es","Español · Spanish"],["ar","العربية · Arabic"],["fr","Français · French"],["bn","বাংলা · Bengali"],["pt","Português · Portuguese"],["ru","Русский · Russian"],["ur","اردو · Urdu"]];
let lang="en",steps=[],idx=0,marked=null;
const t=k=>DATA[lang][KEYS.indexOf(k)]||DATA.en[KEYS.indexOf(k)]||k;

sh.innerHTML=`<style>
*{box-sizing:border-box}.cs-panel{font:14px Inter,ui-sans-serif,system-ui,-apple-system,sans-serif;width:360px;max-height:calc(100vh - 36px);overflow:auto;background:#17171b;color:#f4f2ed;border:1px solid #38383f;border-radius:20px;box-shadow:0 18px 60px #0008;padding:16px}.cs-hidden{display:none!important}.head{display:flex;align-items:center;gap:10px;padding-bottom:12px;border-bottom:1px solid #34343a}.logo{width:38px;height:38px;border-radius:12px;background:#b9f36b;color:#17171b;display:grid;place-items:center;font-size:23px;flex:none}.brand{font-size:16px;font-weight:850;letter-spacing:-.5px;flex:1}.brand span{color:#b9f36b}.tagline{display:block;color:#85858e;font-size:8px;letter-spacing:1px;margin-top:2px;font-weight:750}.close{border:1px solid #414149;background:#25252b;color:#e8e6e1;border-radius:9px;padding:7px 10px;cursor:pointer}.sub{font-size:11px;color:#a3a2aa;margin:12px 0 14px;line-height:1.5}.label{font-size:9px;color:#b9f36b;font-weight:850;letter-spacing:1.3px}.select,.input{width:100%;padding:11px 12px;border:1px solid #414149;border-radius:10px;font-size:13px;background:#232329;color:#f4f2ed;margin:7px 0 14px;outline:none}.select:focus,.input:focus{border-color:#b9f36b;box-shadow:0 0 0 3px #b9f36b20}.question{font-size:19px;font-weight:850;letter-spacing:-.6px;margin:10px 0 6px}.copy{font-size:12px;line-height:1.55;color:#aaa9b0;margin:0 0 13px}.option{width:100%;display:block;text-align:left;padding:12px 13px;margin:8px 0;border:1px solid #38383f;border-radius:12px;background:#222227;color:#f4f2ed;cursor:pointer;transition:.15s}.option:hover{border-color:#b9f36b;background:#292d23;transform:translateY(-1px)}.option b{display:block;font-size:13px}.option small{display:block;color:#96959e;font-size:11px;margin-top:4px;line-height:1.4}.primary{background:#b9f36b;color:#17171b;border:0;border-radius:10px;padding:11px 14px;font-weight:850;cursor:pointer}.secondary{background:#29292f;color:#e9e7e2;border:1px solid #414149;border-radius:10px;padding:11px 14px;cursor:pointer}.row{display:flex;gap:8px;margin-top:13px}.row button{flex:1}.step{font-size:10px;color:#b9f36b;font-weight:850;letter-spacing:1px;margin:16px 0 8px}.instruction{font-size:14px;line-height:1.6;margin:0 0 10px;color:#f1efe9}.reason{font-size:11px;color:#c0bfc5;background:#24242a;border:1px solid #38383f;padding:11px;border-radius:10px;line-height:1.5;margin:12px 0}.reason b{color:#b9f36b}.progress{height:6px;background:#36363d;border-radius:9px;overflow:hidden;margin-top:14px}.progress span{display:block;height:100%;background:#b9f36b;border-radius:9px}.note{font-size:10px;color:#85858e;line-height:1.5;margin-top:13px}.cs-target{outline:3px solid #b9f36b!important;outline-offset:4px!important;scroll-margin:110px!important;box-shadow:0 0 0 7px #b9f36b25!important}.cs-panel[dir=rtl]{direction:rtl;text-align:right}
@media(max-width:420px){.cs-panel{width:min(360px,calc(100vw - 24px));max-height:calc(100vh - 24px)}}
</style><section class="cs-panel" role="dialog" aria-label="ClickSimple assistant"><div class="head"><div class="logo" aria-hidden="true">🐈‍⬛</div><div class="brand">Click<span>Simple</span><small class="tagline">LET EVIL LARRY HELP YOU</small></div><button class="close" aria-label="Close">✕</button></div><p class="sub">Pick a task and Larry will show you where to go.</p><div class="body"></div></section>`;

const panel=sh.querySelector(".cs-panel"),body=sh.querySelector(".body");
sh.querySelector(".close").onclick=()=>{clear();panel.classList.add("cs-hidden")};

const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const norm=s=>(s||"").toLocaleLowerCase().normalize("NFKC").replace(/[’‘]/g,"'").replace(/[^\p{L}\p{N}]+/gu," ").replace(/\s+/g," ").trim();

function visible(e){if(!e||!e.isConnected)return false;const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden"&&Number(s.opacity)!==0}
function label(e){const labs=e.labels&&e.labels.length?[...e.labels].map(x=>x.innerText).join(" "):"";return [e.getAttribute("aria-label"),e.getAttribute("placeholder"),e.getAttribute("alt"),e.title,labs,e.innerText,e.textContent,e.name,e.id].filter(Boolean).join(" ").replace(/\s+/g," ").trim()}
function collect(sel){return [...document.querySelectorAll(sel)].filter(e=>!host.contains(e)&&visible(e))}
function clear(){if(marked&&document.contains(marked))marked.classList.remove("cs-target");marked=null}

function jump(e){
  clear();if(!e||!e.isConnected)return;
  marked=e;e.classList.add("cs-target");
  requestAnimationFrame(()=>{
    if(!e.isConnected)return;
    try{e.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch(_){e.scrollIntoView()}
  });
}

function expandQuery(q){
  const normalized = norm(q);
  const words = normalized.split(" ").filter(Boolean);
  const expanded = new Set(words);
  for(const w of words){
    for(const [key, syns] of Object.entries(SYNONYMS)){
      if(w.includes(key) || key.includes(w) || syns.some(s => w.includes(s) || s.includes(w))){
        expanded.add(key);
        syns.forEach(s => expanded.add(s));
      }
    }
  }
  return { query: normalized, words: Array.from(expanded) };
}

function findMatches(q){
  const { query, words } = expandQuery(q);
  if(!query) return [];
  const selector = 'a[href],button,input:not([type="hidden"]),textarea,select,[role="button"],[role="link"],h1,h2,h3,h4,h5,h6,p,li,label,summary,section,article,div,span';
  const candidates = collect(selector), found = [], seen = new Set();
  
  for(const e of candidates){
    const raw = label(e); if(!raw || raw.length > 8000) continue;
    const txt = norm(raw); if(!txt) continue;
    let hits = 0;
    words.forEach(w => { if(txt.includes(w)) hits++; });
    if(hits === 0) continue;
    
    const key = e.tagName + ":" + txt.slice(0, 200);
    if(seen.has(key)) continue; seen.add(key);
    
    let score = hits * 10;
    if(txt.includes(query)) score += 30;
    const tag = e.tagName.toLowerCase();
    if(["a","button","label","input","textarea","select","h1","h2","h3"].includes(tag)) score += 15;
    if(txt.length < 150) score += 10;
    
    found.push({ el: e, title: raw.slice(0, 80), detail: raw.slice(0, 200), score });
  }

  found.sort((a,b) => b.score - a.score);
  return found.slice(0, 25).map(m => ({
    el: m.el,
    title: m.title || "Match Found",
    detail: m.detail,
    reason: t("reason")
  }));
}

function formSteps(){
  const fields = collect('input:not([type="hidden"]):not([type="submit"]):not([type="button"]),textarea,select').filter(e=>!e.disabled);
  return fields.map((e, idx) => {
    const lbl = label(e) || `Field ${idx + 1}`;
    const type = e.getAttribute("type") || e.tagName.toLowerCase();
    const req = e.required || e.getAttribute("aria-required") === "true" ? " (Required)" : "";
    const ph = e.placeholder ? ` Example: "${e.placeholder}"` : "";
    
    return {
      el: e,
      title: `Step ${idx + 1}/${fields.length}: ${lbl}${req}`,
      detail: `Enter your ${lbl.toLowerCase()} here.${ph} Type: ${type}.`,
      reason: "Inspect field requirements before typing. You remain in full control."
    };
  });
}

function navSteps(){
  return collect('a[href],button,[role="button"],[role="link"],summary').filter(e=>label(e).length>1).slice(0, 20).map(e=>({
    el: e,
    title: label(e).slice(0,75),
    detail: label(e),
    reason: t("reason")
  }));
}

function home(){
  clear();
  panel.dir = ["ar","ur"].includes(lang) ? "rtl" : "ltr";
  body.innerHTML=`<label class="label">${t("tag")}</label><select class="select" id="language">${LANGS.map(([v,n])=>`<option value="${v}" ${v===lang?"selected":""}>${n}</option>`).join("")}</select><div class="question">${t("question")}</div><p class="copy">${t("intro")}</p><button class="option" data-task="form"><b>📝 ${t("form")}</b><small>${t("formDesc")}</small></button><button class="option" data-task="find"><b>🔎 ${t("find")}</b><small>${t("findDesc")}</small></button><button class="option" data-task="nav"><b>🧭 ${t("nav")}</b><small>${t("navDesc")}</small></button><button class="option" data-task="custom"><b>🐾 ${t("custom")}</b><small>${t("customDesc")}</small></button><p class="note">🐈‍⬛ Larry says: no panic. You stay in control of every click.</p>`;
  body.querySelector("#language").onchange=e=>{lang=e.target.value;home()};
  body.querySelectorAll("[data-task]").forEach(b=>b.onclick=()=>begin(b.dataset.task));
}

function begin(task){
  if(task==="form"){
    let a=formSteps();
    start(a.length?a:[{el:null,title:t("noFields"),detail:t("noFields"),reason:t("reason")}]);
    return;
  }
  if(task==="nav"){
    let a=navSteps();
    start(a.length?a:[{el:null,title:t("noNav"),detail:t("noNav"),reason:t("reason")}]);
    return;
  }
  body.innerHTML=`<div class="question">${task==="find"?t("searchTitle"):t("goalTitle")}</div><p class="copy">${t("intro")}</p><input class="input" id="query" placeholder="${esc(task==="find"?t("placeholder"):t("goalPlaceholder"))}"><div class="row"><button class="secondary" id="back">${t("back")}</button><button class="primary" id="go">${t("findBtn")}</button></div>`;
  body.querySelector("#back").onclick=home;
  const run=()=>{
    let q=body.querySelector("#query").value.trim();
    if(!q){body.querySelector("#query").placeholder=t("empty");return;}
    start(findMatches(q));
  };
  body.querySelector("#go").onclick=run;
  body.querySelector("#query").onkeydown=e=>{if(e.key==="Enter")run()};
  body.querySelector("#query").focus();
}

function start(a){
  steps=a.length?a:[{el:null,title:t("noMatch"),detail:t("noMatch"),reason:t("reason")}];
  idx=0; render();
}

function render(){
  const s=steps[idx];
  if(s.el) jump(s.el); else clear();
  let pct=Math.round((idx+1)/steps.length*100);
  body.innerHTML=`<div class="step">${t("step")} ${idx+1} / ${steps.length}</div><div class="question">${esc(s.title)}</div><p class="instruction">${esc(s.detail)}</p><div class="reason"><b>${t("why")}</b><br>${esc(s.reason)}</div><div class="progress"><span style="width:${pct}%"></span></div><div class="row"><button class="secondary" id="back">${t("back")}</button><button class="primary" id="next">${idx===steps.length-1?t("finish"):t("next")}</button></div><p class="note">🐈‍⬛ Larry says: no panic. You stay in control of every click.</p>`;
  body.querySelector("#back").onclick=home;
  body.querySelector("#next").onclick=()=>{
    if(idx<steps.length-1){idx++;render()}else home();
  };
}

home();
})();
