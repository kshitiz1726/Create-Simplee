# ClickSimple V5.0.0 (Fully Resolved Edition)
- Solved duplicate word issues across labels ("home home").
- Added deep iframe/embedded DOM element collection.
- Added Search Bar inside "Fill out a form" mode.
- Fixed auto-scrolling across Describe My Task and all search modes.
- Restricted results to top 3-5 high-precision matches based on combined word intent.
