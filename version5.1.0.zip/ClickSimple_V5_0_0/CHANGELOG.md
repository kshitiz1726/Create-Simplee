# CHANGELOG - ClickSimple V5.0.0 Final
- Fixed word repetition.
- Restored form search bar.
- Implemented deep embedded page navigation.
- Fixed describe my task auto-scroll.
- Implemented top 3-5 combined word precision matching.
