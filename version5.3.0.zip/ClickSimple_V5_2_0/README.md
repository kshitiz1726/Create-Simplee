# ClickSimple V5.2.0 — Embedded Guidance Edition

ClickSimple is a local-first Chrome extension that helps people understand and navigate complex websites. It does not call an external AI service, create a cloud account, or send page content to a remote server.

## What's new in V5.2.0

- **Better embedded-page coverage:** ClickSimple scans the main page, open shadow roots, and accessible same-site iframes. For cross-site embedded frames, use **Include embedded pages on this site** in the extension popup. Chrome then asks for access only to the external origins embedded in the current page. You can decline and continue using ClickSimple on the main page.
- **Embedded result highlighting:** When an item is found inside an accessible embedded frame, ClickSimple can scroll to and highlight that item within its frame.
- **Built-in website guide:** Navigate this website now has short, built-in explanations for common areas such as accounts, dashboards, orders, payments, carts, checkout, help, settings, documents, courses, admissions, results, schedules, attendance, and contact pages. These are general guides, not claims about a site's private behavior; the wording says "usually" where the exact purpose can vary.
- **Simpler task descriptions:** Describe my task uses shorter guidance such as the section name and where to look, instead of repeating large chunks of page text.
- **Clearer form-field names:** Labels and accessibility names are preferred. Helpful placeholders are used before generic IDs such as `field1` or `input2`, and each field gets a short note about what information belongs there.

## V5.1.0 guided browsing is retained

- **Guided cross-page search:** When a search has no result on the current page, users can start a guided journey. ClickSimple keeps the search goal in local extension storage, suggests relevant links or navigation choices, and checks each page the user opens.
- **Journey resumes after navigation:** On pages within the same origin, ClickSimple automatically reopens and checks the saved search. If a journey moves to a different origin or opens in a new tab and Chrome blocks automatic injection, click the ClickSimple toolbar icon on that tab to grant access and resume.
- **Context-aware navigation explanations:** Links are described using their actual destinations. Buttons are explained using available HTML and accessibility metadata, such as form submission, reset behavior, expanded/collapsed state, popup type, and nearby section headings. When the page does not expose a control's exact action, ClickSimple says so rather than inventing an explanation.
- **Local-only journey state:** Search journeys are stored in `chrome.storage.local`, scoped to the tab, and removed when the user finishes the journey or closes the tab.

## How to enable embedded-page inspection

1. Open the website you want to inspect.
2. Click the ClickSimple extension icon.
3. Choose **Include embedded pages on this site**.
4. Review Chrome's permission prompt and grant access only if you are comfortable with it.
5. Reopen ClickSimple on that page and use its normal modes.

The permission prompt is limited to external website origins that are embedded in the current page. ClickSimple does not request blanket access to every website. If a frame is sandboxed, blocked by the browser, or nested under an inaccessible third-party frame, some of its content may remain unavailable. The extension does not bypass website or browser security restrictions.

## How guided search works

1. Open ClickSimple on a website and choose **Find something**.
2. Enter the item or task you are looking for.
3. If it is not present on the current page, choose **Guide me there**.
4. Review the suggested links, use **Highlight this option**, and click the corresponding link on the website yourself.
5. ClickSimple checks the next page and either shows a possible match or suggests the next navigation choices.
6. Choose **Finish search** when done.

ClickSimple does not inspect unopened pages or click links automatically. It guides the user through pages they choose to open.

## Permissions

- `activeTab`: grants access after the user invokes the extension on a tab.
- `scripting`: injects the local content script and inspects frames for which access is available.
- `storage`: stores the active guided-search goal locally, scoped to a tab.
- `optional_host_permissions`: requests access only to cross-site embedded origins when the user presses the embedded-page permission button. No host access is granted by default.

## Install in Chrome

1. Extract the ZIP file.
2. Open `chrome://extensions` in Chrome or Edge.
3. Turn on **Developer mode**.
4. Select **Load unpacked** and choose the extracted `ClickSimple_V5_2_0` folder.
5. Pin ClickSimple to the toolbar, open a website, and select **Let Larry help me**.

## Project files

```text
ClickSimple_V5_2_0/
├── manifest.json
├── background.js
├── popup.html
├── popup.css
├── popup.js
├── content.js
├── README.md
└── CHANGELOG.md
```

## Existing behavior retained

- Four modes: Fill out a form, Find something, Navigate this website, and Describe my task.
- Ten language choices and RTL panel direction for Arabic and Urdu.
- Integrated form search and top-ranked search results.
- Guided multi-page search with local tab-scoped journey state.
- Duplicate-word cleanup, highlighted results, and smooth scrolling.
- Local-first operation without external AI APIs, cloud accounts, or tracking.
